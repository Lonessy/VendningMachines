﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LobanovNapit
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        AvtomatEntities4 db = new AvtomatEntities4();
        VendingMachineCoins coin1;
        VendingMachineCoins coin2;
        VendingMachineCoins coin5;
        VendingMachineCoins coin10;
        public Page1()
        {
            InitializeComponent();
            coin1 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 1);
            coin2 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 2);
            coin5 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 5);
            coin10 = db.VendingMachineCoins.FirstOrDefault(x => x.Coins.Denomination == 10);
            Coin1.Text = Convert.ToString(coin1.Count);
            Coin2.Text = Convert.ToString(coin2.Count);
            Coin5.Text = Convert.ToString(coin5.Count);
            Coin10.Text = Convert.ToString(coin10.Count);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            coin1.Count = Convert.ToInt32(Coin1.Text);
            coin2.Count = Convert.ToInt32(Coin2.Text);
            coin5.Count = Convert.ToInt32(Coin5.Text);
            coin10.Count = Convert.ToInt32(Coin10.Text);
            db.SaveChanges();
        }
    }
}
